#!/bin/bash
echo "Hello World!"
echo 'Hello World!'
