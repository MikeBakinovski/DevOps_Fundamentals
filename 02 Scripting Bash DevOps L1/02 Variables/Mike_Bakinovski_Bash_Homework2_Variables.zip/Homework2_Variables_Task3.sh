#!/bin/bash

echo "MY_VAR=${MY_VAR:-default}"
