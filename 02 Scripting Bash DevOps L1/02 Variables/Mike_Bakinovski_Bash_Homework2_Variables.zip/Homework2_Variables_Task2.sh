#!/bin/bash

var1="Hello,"

var2="broken"

var3="script"

printf "%s %s %s\n" "$var1" "$var2" "$var3"
