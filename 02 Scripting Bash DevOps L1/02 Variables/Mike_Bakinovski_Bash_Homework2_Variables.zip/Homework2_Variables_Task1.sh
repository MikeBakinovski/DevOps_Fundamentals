#!/bin/bash
cdate=$(date)
echo [$cdate] Hello, task2!
