#!/bin/bash
echo $(seq 10)